# Table Extraction
This project deals with detecting and extracting tables from images. Uses Open CV.
